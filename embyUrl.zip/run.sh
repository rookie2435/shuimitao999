#!/bin/sh
docker rm -f emby-nginx
cd /root/embyUrl
docker compose up -d
