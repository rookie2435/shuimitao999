//author: @bpking  https://github.com/bpking1/embyExternalUrl
//查看日志: "docker logs -f -n 10 emby-nginx 2>&1  | grep js:"
async function redirect2Pan(r) {
    //根据实际情况修改下面的设置
    const embyHost = 'http://140.83.63.238:8096'; 
    const embyMountPath = '/mnt'; 
    const embyApiKey = '3fff4b39fff844caa134553f842384c4';
    const LinearChai = 'http://116.181.11.141'
    //fetch mount emby/jellyfin file path
    const regex = /[A-Za-z0-9]+/g;
    const itemId = r.uri.replace('emby', '').replace(/-/g, '').match(regex)[1];
    const mediaSourceId = r.args.MediaSourceId ? r.args.MediaSourceId : r.args.mediaSourceId;
    const Etag = r.args.Tag
    let api_key = r.args['X-Emby-Token'] ? r.args['X-Emby-Token'] : r.args.api_key;
    api_key = api_key ? api_key : embyApiKey;

    let itemInfoUri = '';
    if (mediaSourceId) {
        itemInfoUri = `${embyHost}/Items/${itemId}/PlaybackInfo?MediaSourceId=${mediaSourceId}&api_key=${api_key}`;
    }else{
        itemInfoUri = `${embyHost}/Items/${itemId}/PlaybackInfo?api_key=${api_key}`;
    }
    
    const embyRes = await fetchEmbyFilePath(itemInfoUri, Etag);
    if (embyRes.startsWith('error')) {
        r.error(embyRes);
        r.return(500, embyRes);
        return;
    }
    r.warn(`mount emby file path: ${embyRes}`);

    let alistRes = embyRes.replace(embyMountPath, '');
        alistRes =  `${LinearChai}:32400${alistRes}`;
        r.warn(`redirect to: ${alistRes}`);
    r.return(302, alistRes);
    return;
}

async function fetchEmbyFilePath(itemInfoUri, Etag) {
    try {
        const res = await ngx.fetch(itemInfoUri, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
                'Content-Length': 0,
            },
            max_response_body_size: 65535,
        });
        if (res.ok) {
            const result = await res.json();
            if (result === null || result === undefined) {
                return `error: emby_api itemInfoUri response is null`;
            }
            if (Etag) {
                const mediaSource = result.MediaSources.find(m => m.ETag == Etag);
                if (mediaSource && mediaSource.Path) {
                    return mediaSource.Path;
                }
            }
            return result.MediaSources[0].Path;
        }
        else {
            return (`error: emby_api ${res.status} ${res.statusText}`);
        }
    }
    catch (error) {
        return (`error: emby_api fetch mediaItemInfo failed,  ${error}`);
    }
}

export default { redirect2Pan };